module.exports.cilentId = "1067014290429-vpsq0r3brthhhaohj1kbb3cqg1u1aahl.apps.googleusercontent.com";
module.exports.cilentSecret = "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";
